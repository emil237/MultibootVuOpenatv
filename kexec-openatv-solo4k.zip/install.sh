#!/bin/sh

if [[ ! -f /proc/stb/info/vumodel ]]; then
    echo "your box isnt a vuplus"
fi

MODEL=$(cat /proc/stb/info/vumodel)

grep -q "^$MODEL$" target.txt
if [ $? != 0 ]; then
    echo "installer mismatch with the current box"
    exit 1
fi

if [ ! -f /usr/lib/enigma.info ]; then
    echo "you need an image with /usr/lib/enigma.info (eg latest openatv 7.xx)"
    exit 1
fi

distro=`grep ^distro= /usr/lib/enigma.info`
imageversion=`grep ^imageversion= /usr/lib/enigma.info | sed "s/['\"]//g"`

if [ ${distro#*=} != "openatv" ]; then
    echo "distro needs to be openatv"
    exit 1
fi

if [ ${distro#*=} = "openatv" ] && [ ${imageversion#*=} = "7.2" ]; then
    echo "Update patch"
    cp FlashManager.py /usr/lib/enigma2/python/Screens/FlashManager.py
    cp SystemInfo.py /usr/lib/enigma2/python/Components/SystemInfo.py
    cp MultiBoot.py /usr/lib/enigma2/python/Tools/MultiBoot.py
       
fi

case $MODEL in
solo4k|uno4k|ultimo4k)
    KERNEL=mmcblk0p1
    ROOTFS=mmcblk0p4
;;
uno4kse)
    KERNEL=mmcblk0p1
    ROOTFS=mmcblk0p4
;;
zero4k)
    KERNEL=mmcblk0p4
    ROOTFS=mmcblk0p7
;;
duo4k|duo4kse)
    KERNEL=mmcblk0p6
    ROOTFS=mmcblk0p9
;;
*)
    echo "this box isn't supported yet"
;;
esac

echo "Backupping ofgwrite"
[[ ! -f /usr/bin/ofgwrite_bin.bkp ]] && mv /usr/bin/ofgwrite_bin /usr/bin/ofgwrite_bin.bkp
echo "updating ofgwrite"
mv ofgwrite_bin /usr/bin/ofgwrite_bin
chmod 755 /usr/bin/ofgwrite_bin

echo "Fix for previous installation (rename kernel_auto.bin to zImage)"
cat /proc/mounts | grep -q '/boot' && umount /boot
[[ -f /boot/kernel_auto.bin ]] && mv /boot/kernel_auto.bin /zImage
[[ -f /linuxrootfs1/boot/kernel_auto.bin ]] && mv /linuxrootfs1/boot/kernel_auto.bin /linuxrootfs1/zImage
[[ -f /linuxrootfs2/boot/kernel_auto.bin ]] && mv /linuxrootfs2/boot/kernel_auto.bin /linuxrootfs2/zImage
[[ -f /linuxrootfs3/boot/kernel_auto.bin ]] && mv /linuxrootfs3/boot/kernel_auto.bin /linuxrootfs3/zImage
[[ -f /linuxrootfs4/boot/kernel_auto.bin ]] && mv /linuxrootfs4/boot/kernel_auto.bin /linuxrootfs4/zImage

echo "downloading startup image"
mv STARTUP.cpio.gz /STARTUP.cpio.gz
echo "creating startup profiles"
printf "kernel=/zImage root=/dev/${ROOTFS} rootsubdir=linuxrootfs0" > /STARTUP
printf "kernel=/zImage root=/dev/${ROOTFS} rootsubdir=linuxrootfs0" > /STARTUP_RECOVERY
printf "kernel=/linuxrootfs1/zImage root=/dev/${ROOTFS} rootsubdir=linuxrootfs1" > /STARTUP_1
printf "kernel=/linuxrootfs2/zImage root=/dev/${ROOTFS} rootsubdir=linuxrootfs2" > /STARTUP_2
printf "kernel=/linuxrootfs3/zImage root=/dev/${ROOTFS} rootsubdir=linuxrootfs3" > /STARTUP_3
#printf "kernel=/linuxrootfs4/zImage root=/dev/${ROOTFS} rootsubdir=linuxrootfs4" > /STARTUP_4
#printf "kernel=/linuxrootfs4/zImage root=UUID=\"12c2025e-2969-4bd1-9e0c-da08b97d40ce\" rootsubdir=linuxrootfs1" > /_STARTUP_4

echo "backup original kernel"
[[ ! -f /zImage ]] && dd if=/dev/${KERNEL} of=/zImage
echo "flashing multiboot kernel"
dd if=/tmp/kernel_auto.bin of=/dev/${KERNEL}
sync; sleep 1; sync; sleep 1; sync

echo "Make a full backup of your image, you can restore it in another slot later."
echo "The current image will be preserved to recover the box if something goes wrong"
echo "Now you can reboot, then install your backup image or a new image via imagemanager into 1 of the available slots"

echo "*****************************************"
echo "To recover the box if something goes wrong:"
echo " - Put on your usb stick /vuplus/ultimo4k/kernel_auto.bin from your installed image and reflash it"
echo " - Boot your box and connect to it with putty or an ftp client and delete /STARTUP*"
echo " - Reboot your box"

#unsupported notes
#flash usb slot 5 from vuplus
#/usr/bin/ofgwrite -rsdb1 -kzImage -m5 '/media/hdd/imagebackups/imagerestore/vuplus/ultimo4k'
#create file /STARTUP_5
#kernel=/linuxrootfs5/zImage root=/dev/sdb1 rootsubdir=linuxrootfs5" > /STARTUP_5

#flash on slot 2 (flash)
#/usr/bin/ofgwrite -n -r -k -m2 '/media/hdd/imagebackups/imagerestore/vuplus/ultimo4k'
